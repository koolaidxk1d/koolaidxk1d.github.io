## Bug Collector's Plight

A boy named Ralston requests help completing a collection....of bugs.

---

<ins>Notes for admissions:</ins>

- Starting cell is AlchemistsShackExterior
- Game version: 1.6.640
- CK Version: 1.6.438  [+CKPE]
